<div id="loadMorePostsTrigger" class="row archive__load-more">
	<div class="col-12 text-center my-5">
		<div class="archive__load-more-text">
			<?php _e( 'Loading...', 'dp' ); ?>
		</div>
	</div>
</div>
