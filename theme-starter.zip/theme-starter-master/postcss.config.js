module.exports = {
	plugins: {
		autoprefixer: {
			overrideBrowserslist: [ 'last 3 versions', '>1%' ]
		}
	}
};
