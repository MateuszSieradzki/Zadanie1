<?php
require_once 'inc/classes/class-theme.php';
require_once 'inc/helpers/svg.php';

new Theme();
