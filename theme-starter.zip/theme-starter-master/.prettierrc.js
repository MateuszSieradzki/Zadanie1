module.exports = {
    "jsxBracketSameLine": false,
};
